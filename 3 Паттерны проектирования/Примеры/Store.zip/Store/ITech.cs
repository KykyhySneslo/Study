﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store
{
    public interface ITech
    {
        public void Load(); //гарантирует что устройство можно включить
        public string GetInfo(); //гарантирует вывод информации об устройстве

    }
}
