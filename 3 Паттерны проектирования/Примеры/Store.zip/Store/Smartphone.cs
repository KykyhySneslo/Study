﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store
{
    /// <summary>
    /// конкретный тип техники, реализующий интерфейс Itech
    /// </summary>
    internal class Smartphone : ITech
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public Smartphone(string n, double p) { Name = n; Price = p; }
        public void Load()
        {
            Console.WriteLine("смарфон включен");
        }
        public string GetInfo()
        {
            return "смартфон модели: " + Name + "\nЦена: " +Price;
        }
    }
}
