﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store
{
    abstract public class Creator
    {
        //public string Name { get; set; } 
        //public Creator(string n) { Name = n; }
        /// <summary>
        /// фабричный метод, заявляющий генерацию объектов реализ интерф ITech
        /// </summary>
        /// <param name="n">название</param>
        /// <param name="p">цена</param>
        /// <returns></returns>
        abstract public ITech GenerateTech(string n, double p); 

    }

    public class SmartphoneCreator : Creator
    {
        public override ITech GenerateTech(string n, double p)
        {
            Smartphone s = new Smartphone(n, p);
            return s;
        }
    }


    public class NotebookCreator : Creator
    {
        public override ITech GenerateTech(string n, double p)
        {
            Notebook notebook = new Notebook(n, p);
            return notebook;
        }
    }
}
