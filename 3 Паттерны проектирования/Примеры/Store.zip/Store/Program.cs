﻿namespace Store
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<ITech> teches = new List<ITech>();

            SmartphoneCreator smCreator = new SmartphoneCreator();

            teches.Add(smCreator.GenerateTech("samsung", 10000));
            teches.Add(smCreator.GenerateTech("iphone", 10000));

            NotebookCreator nbCr= new NotebookCreator();

            teches.Add(nbCr.GenerateTech("HP", 20000));

            // основная функциональность (перебор коллекции ) не нарушается при добавлении в нее объектов новых типов
            foreach(ITech t in teches)
            {
                t.Load();
                Console.WriteLine(t.GetInfo());
            }

        }
    }
}