﻿namespace AdapterDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Client client = new Client();

            client.users.Add(new User("имя1", "email1@dhgf.ru", new DateTime(2020, 12, 16)));
            client.users.Add(new User("имя2", "email2@dhgf.ru", new DateTime(2021, 10, 01)));
            client.users.Add(new User("имя3", "email3@dhgf.ru", new DateTime(2022, 09, 01)));

            

            Dog dog1 = new Dog("собака1 ", new DateTime(2022, 11, 10));
            AdapterToDogs adapter = new AdapterToDogs();
            client.users.Add(adapter.DogToUser(dog1));

            User oldUser = (User)client.GetYang();
            Console.WriteLine(oldUser);

            foreach(User u in client.users)
                Console.WriteLine(u);

        }
    }
}