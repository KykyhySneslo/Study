﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterDemo
{
    public  class Dog
    {
        public string Name { get; set; }
        public DateTime BirthDay { get; set; }

        public Dog(string s,  DateTime d)
        {
            Name = s; BirthDay = d; 
        }

        public Dog() { }

        public override string ToString()
        {
            return "dog name: " +Name+ " data birth: " +BirthDay;
        }

        public string GetAgeOfDog()
        {
            return (DateTime.Now - BirthDay).ToString();
        }

    }
}
