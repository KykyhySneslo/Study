﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterDemo
{
    public class Client 
    {
        public List<User> users =new List<User>();

       

        /// <summary>
        /// возвращающий старейший контакт в списке
        /// </summary>
        /// <returns></returns>
        public Object GetYang()
        {
            User user = new User();
            TimeSpan min = TimeSpan.Zero;   
            foreach(User u in users)
            {
                if (u.GetAge() > min)
                {
                    user = u;
                    min = u.GetAge();
                }
            }

            return user;
        }
    }
}
