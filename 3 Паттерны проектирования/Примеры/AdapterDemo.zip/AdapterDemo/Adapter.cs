﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterDemo
{
    public class AdapterToDogs : ClientInterface
    {
        public Dog dog {get;set;}

        public  User DogToUser(Dog dog)
        {
            return new User(dog.Name, "none", dog.BirthDay);
        }
        public TimeSpan GetAge()
        {
            TimeSpan ts = TimeSpan.Parse(dog.GetAgeOfDog());

            return ts;  
        }

    }
}
