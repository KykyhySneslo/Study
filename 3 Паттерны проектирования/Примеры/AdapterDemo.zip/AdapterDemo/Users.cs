﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterDemo
{
    public class User
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime DataRegistr { get; set; }

        public User() { }

        public User (string n, string e, DateTime dataRegistr)
        {
            Name = n; Email = e; DataRegistr=dataRegistr;
        }

        public override string ToString()
        {
            return "пользователь " + Name + "зарегестрирован от " + DataRegistr.ToShortDateString() ; 
        }

        public TimeSpan GetAge()
        {
            return DateTime.Now - DataRegistr;
        }
    }

}
