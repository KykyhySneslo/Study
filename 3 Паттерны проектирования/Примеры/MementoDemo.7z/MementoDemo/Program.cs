﻿
namespace MementoDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Player player= new Player();

            Console.WriteLine(player);
            player.Move(Direction.left);

            Console.WriteLine(player);
            player.Move(Direction.up);
            Console.WriteLine(player);

            //сохранение состояния
            Storage storage = new Storage(player);
            storage.AddState();

            player.Move(Direction.up);
            Console.WriteLine(player);

            player.Move(Direction.left);
            Console.WriteLine(player);

            storage.ReturnState();

            Console.WriteLine(player);

        }
    }
}