﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MementoDemo
{
    public enum Direction { right, left, up, down };
    public  class Player //Originator
    {
        private int health = 6;
        private int x = 5;
        private int y = 5;

        public void Move(Direction dir)
        {
            health--;
            switch (dir)
            {
                case Direction.left:    x--; break;
                case Direction.up:      y--; break;
                case Direction.down:    y++; break;
                case Direction.right:   x++; break;

            }
            
        }

        public override string ToString()
        {
            return "игрок переместился на координаты " + x +"," +y +" здоровье: " + health;
        }

        public class Memento //снимок состояния
        {
            public  int health { get; private set; }
            public int x { get; private set; }
            public int y { get; private set; }

            public Memento(int h, int x, int y)
            {
                health = h; this.x = x; this.y = y;
            }


        }
        /// <summary>
        /// сохранение состояния
        /// </summary>
        /// <returns>снимок</returns>
        public Memento SaveState() 
        {
            return new Memento(health, x, y);
        }
        /// <summary>
        /// загрузка состояния из снимка
        /// </summary>
        /// <param name="m"></param>
        public void LoadState(Memento m)
        {
            health = m.health;
            x = m.x; y = m.y;
        }
    }

    public class Storage // Caretaker
    {
        private Player player;
        public Stack<Player.Memento> states = new Stack<Player.Memento>();

        public Storage(Player p)
        {
            player = p;
        }
        public void AddState()
        {
            states.Push(player.SaveState());
        }

        public void ReturnState()
        {
            player.LoadState(states.Pop());
        }
    }
}
